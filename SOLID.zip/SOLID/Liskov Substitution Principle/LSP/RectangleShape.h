#pragma once
public ref class RectangleShape
{
public:
	RectangleShape() {};
	RectangleShape( int, int );
	virtual int GetWidth() { return _width; };
	virtual int GetHeight() { return _height; };
	virtual void SetWidth( int value ) { _width = value; };
	virtual void SetHeight( int value ) { _height = value; };
	~RectangleShape() {};
private:
	int _width = 0;
	int _height = 0;
};

public ref class SquareShape : RectangleShape
{
public:
	SquareShape() {};
	SquareShape( int side ) : RectangleShape( side, side ) {};
	void SetWidth( int value ) override { RectangleShape::SetWidth( value ); RectangleShape::SetHeight( value ); };
	void SetHeight( int value ) override { RectangleShape::SetWidth( value ); RectangleShape::SetHeight( value );};
	~SquareShape() {};
private:
};

public ref class AreaCalculator
{
public:
	AreaCalculator() {};
	~AreaCalculator() {};
	static int CalculateArea( RectangleShape^ r );
	static int CalculateArea( SquareShape^ r );
private:

};
