#include "RectangleShape.h"

using namespace System;
using namespace System::Text;
using namespace System::Collections::Generic;
using namespace Microsoft::VisualStudio::TestTools::UnitTesting;

RectangleShape::RectangleShape( int width, int height )
{
	_width = width;
	_height = height;
}

int AreaCalculator::CalculateArea( RectangleShape^ r )
{
	return r->GetWidth()*r->GetHeight();
}

int AreaCalculator::CalculateArea( SquareShape^ r )
{
	return r->GetHeight()*r->GetHeight();
}

[TestClass]
public ref class CalculateAreaShouldReturn
{	
public:
	[TestMethod]
	void SixFor2X3Rectangle()
	{
		RectangleShape^ myRectangle = gcnew RectangleShape( 2, 3 );
		Assert::AreEqual( 6, AreaCalculator().CalculateArea( myRectangle ) );
	}

	[TestMethod]
	void NineFor3X3Square()
	{
		SquareShape^ mySquare = gcnew SquareShape(3);
		Assert::AreEqual( 9, AreaCalculator().CalculateArea( mySquare ) );
	}

	[TestMethod]
	void TwentyFor4X5RectangleFromSquare()
	{
		RectangleShape^ newRectangle = gcnew SquareShape();
		newRectangle->SetWidth(4);
		newRectangle->SetHeight(5);
		Assert::AreEqual( 20, AreaCalculator().CalculateArea( newRectangle ) );
	}
};