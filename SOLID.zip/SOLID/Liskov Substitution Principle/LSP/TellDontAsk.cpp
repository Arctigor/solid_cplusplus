#include "NoInherit.h"
#include "TellDontAsk.h"

using namespace System;
using namespace System::Text;
using namespace System::Collections::Generic;
using namespace Microsoft::VisualStudio::TestTools::UnitTesting;

[TestClass]
public ref class NoAsk
{

public:
	[TestMethod]
	void SixFor2X3Rectangle()
	{
		RectangleShapeNoAsk^ myRectangle = gcnew RectangleShapeNoAsk( 2, 3 );
		Assert::AreEqual( 6, myRectangle->Area() );
	}

	[TestMethod]
	void NineFor3X3Square()
	{
		SquareShapeNoAsk^ mySquare = gcnew SquareShapeNoAsk(3);
		Assert::AreEqual( 9, mySquare->Area() );
	}

	[TestMethod]
	void TwentyFor4X5ShapeFromRectangleAnd9For3X3Square()
	{
		List<ShapeNoAsk^>^ shapes = gcnew List<ShapeNoAsk^>();
		shapes->Add( gcnew RectangleShapeNoAsk( 4, 5 ) );
		shapes->Add( gcnew SquareShapeNoAsk(3) );
		List<int>^ areas = gcnew List<int>();
		
		for each( ShapeNoAsk^ shape in shapes )
		{		
				areas->Add( shape->Area() );			
		}
		Assert::AreEqual( 20, areas[0] );
		Assert::AreEqual( 9, areas[1] );
	}
};


RectangleShapeNoAsk::RectangleShapeNoAsk( int width, int height )
{
	_width = width;
	_height = height;
}
