#pragma once
public ref class ShapeNoAsk
{
public:
	ShapeNoAsk() {};
	virtual int Area()=0;
};


public ref class RectangleShapeNoAsk : ShapeNoAsk
{
public:
	RectangleShapeNoAsk() {};
	RectangleShapeNoAsk( int, int );
	int GetWidth() { return _width; };
	int GetHeight() { return _height; };
	void SetWidth( int value ) { _width = value; };
	void SetHeight( int value ) { _height = value; };
	int Area() override { return _width*_height; }
	~RectangleShapeNoAsk() {};
private:
	int _width = 0;
	int _height = 0;
};

public ref class SquareShapeNoAsk : ShapeNoAsk
{
public:
	SquareShapeNoAsk() {};
	SquareShapeNoAsk( int side ) { _side = side; };
	int GetSide() { return _side; };
	void SetSide( int value ) { _side = value; };
	int Area() override { return _side*_side; }
	~SquareShapeNoAsk() {};
private:
	int _side = 0;
};

