#include "ISP.h"



String^ ISP::InternalCombustionCar::Start()
{
	_currentGear = 0;
	return "Car started";
}

String^ ISP::InternalCombustionCar::Stop()
{
	_currentGear = 0;
	return "Car stopped";
}

String^ ISP::InternalCombustionCar::Steer()
{
	return "Car is steering";
}

String^ ISP::InternalCombustionCar::Accelerate()
{
	return "Car accelerates";
}

String^ ISP::InternalCombustionCar::Brake()
{
	return "Brakes applied";
}

String^ ISP::InternalCombustionCar::ChargeMainBattery()
{
	throw gcnew System::NotImplementedException();
}

String^ ISP::InternalCombustionCar::FillFuelTank()
{
	return "The fuel tank is full";
}

String^ ISP::InternalCombustionCar::ChangeGear(int gear)
{
	_currentGear = gear;
	return "Gear change complete";
}

String^ ISP::ElectricCar::Start()
{
	return "Car started";
}

String^ ISP::ElectricCar::Stop()
{
	return "Car stopped";
}

String^ ISP::ElectricCar::Steer()
{
	return "Car is steering";
}

String^ ISP::ElectricCar::Accelerate()
{
	return "Car accelerates";
}

String^ ISP::ElectricCar::Brake()
{
	return "Brakes applied";
}

String^ ISP::ElectricCar::ChargeMainBattery()
{
	return "Batteries charged";
}

String^ ISP::ElectricCar::FillFuelTank()
{
	throw gcnew System::NotImplementedException();
}

String^ ISP::ElectricCar::ChangeGear(int)
{
	throw gcnew System::NotImplementedException();
}

String ^ ISP::AutomaticInternalCombustionCar::Start()
{
	return "Car started";
}

String ^ ISP::AutomaticInternalCombustionCar::Stop()
{
	return "Car stopped";
}

String ^ ISP::AutomaticInternalCombustionCar::Steer()
{
	return "Car is steering";
}

String ^ ISP::AutomaticInternalCombustionCar::Accelerate()
{
	return "Car accelerates";
}

String ^ ISP::AutomaticInternalCombustionCar::Brake()
{
	return "Brakes applied";
}

String ^ ISP::AutomaticInternalCombustionCar::ChargeMainBattery()
{
	throw gcnew System::NotImplementedException();
}

String ^ ISP::AutomaticInternalCombustionCar::FillFuelTank()
{
	return "The fuel tank is full";
}

String ^ ISP::AutomaticInternalCombustionCar::ChangeGear(int)
{
	throw gcnew System::NotImplementedException();
}
