#pragma once
using namespace System;
namespace ISP_Refactored {


	interface class IVehicle
	{
	public:
		String^ Start();
		String^ Stop();
		String^ Steer();
		String^ Accelerate();
		String^ Brake();
	};

	interface class IElectric :IVehicle
	{
	public:
		virtual String^ ChargeMainBattery();
	};

	interface class IInternalCombustion :IVehicle
	{
	public:
		virtual String^ FillFuelTank();
	};
	interface class IManual :IInternalCombustion
	{
	public:
		virtual String^ ChangeGear(int);
		static int _currentGear;
	};

	interface class IAutomatic :IInternalCombustion
	{

	};

	public ref class InternalCombustionCar :IManual
	{
	public:
		// Inherited via IInternalCombustion
		virtual String ^ Start();
		virtual String ^ Stop();
		virtual String ^ Steer();
		virtual String ^ Accelerate();
		virtual String ^ Brake();

		// Inherited via IManual
		virtual String ^ FillFuelTank();
		virtual String ^ ChangeGear(int);
		static int _currentGear;
	};

	public ref class AutomaticInternalCombustionCar :IAutomatic
	{
	public:
		// Inherited via IInternalCombustion
		virtual String ^ Start();
		virtual String ^ Stop();
		virtual String ^ Steer();
		virtual String ^ Accelerate();
		virtual String ^ Brake();

		// Inherited via IAutomatic
		virtual String ^ FillFuelTank();
	};

	public ref class ElectricCar :IElectric
	{
	public:
		// Inherited via IElectric
		virtual String ^ Start();
		virtual String ^ Stop();
		virtual String ^ Steer();
		virtual String ^ Accelerate();
		virtual String ^ Brake();
		virtual String ^ ChargeMainBattery();
	};
}
