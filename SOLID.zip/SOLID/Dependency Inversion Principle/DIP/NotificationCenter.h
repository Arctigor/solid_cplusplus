#pragma once
#include "IGenericMessage.h"
#include "MessagesNonInherit.h"
#include "Messages.h"

interface class INotificationCenter
{
public:
	virtual void SendNotifications();
};

using namespace System;
using namespace Collections::Generic;
ref class NotificationCenter:INotificationCenter
{
public:
	NotificationCenter();
	List<IGenericMessage^>^ _messages;
	virtual void SendNotifications();
};

using namespace MessagesNoInherit;
ref class NotificationCenterNonInherit :INotificationCenter
{
public:
	NotificationCenterNonInherit();
	SMSMessage^ _sms;
	MailMessage^ _email;
	ChatMessage^ _chat;
	virtual void SendNotifications();
};

