#pragma once

#include "IGenericMessage.h";

using namespace System;
namespace Messages {
	ref class MailMessage :IGenericMessage
	{
	public:
		MailMessage();
		MailMessage(String^, String^, String^);
		String^ _recipient;
		String^ _subject;
		String^ _message;
		// Inherited via IGenericMessage
		virtual bool Send();
	};

	ref class SMSMessage :IGenericMessage
	{
	public:
		SMSMessage();
		SMSMessage(String^, String^);
		String^ _phoneNumber;
		String^ _message;
		// Inherited via IGenericMessage
		virtual bool Send();
	};

	ref class ChatMessage : IGenericMessage
	{
	public:
		ChatMessage();
		ChatMessage(String^, String^);
		String^ _recipient;
		String^ _message;
		// Inherited via IGenericMessage
		virtual bool Send();
	};
}
