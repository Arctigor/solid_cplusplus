// This is the main DLL file.
#include "DIP.h"

