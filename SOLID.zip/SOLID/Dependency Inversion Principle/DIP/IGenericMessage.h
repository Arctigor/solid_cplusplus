#pragma once
interface class IGenericMessage
{
public:
	virtual bool Send();
};

