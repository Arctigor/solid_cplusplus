#pragma once

#include "IGenericMessage.h";

using namespace System;
namespace MessagesNoInherit {
	ref class MailMessage
	{
	public:
		MailMessage();
		MailMessage(String^, String^, String^);
		String^ _recipient;
		String^ _subject;
		String^ _message;
		bool SendEmail();
	};

	ref class SMSMessage
	{
	public:
		SMSMessage();
		SMSMessage(String^, String^);
		String^ _phoneNumber;
		String^ _message;
		bool SendSMS();
	};

	ref class ChatMessage
	{
	public:
		ChatMessage();
		ChatMessage(String^, String^);
		String^ _recipient;
		String^ _message;
		bool SendChat();
	};
}