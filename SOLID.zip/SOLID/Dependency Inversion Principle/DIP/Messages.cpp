#include "Messages.h"
namespace Messages {
	MailMessage::MailMessage() :MailMessage("a@a.com", "test", "test")
	{
	}

	MailMessage::MailMessage(String ^ rec, String ^ sub, String ^ msg)
	{
		_recipient = rec;
		_subject = sub;
		_message = msg;
	}

	bool MailMessage::Send()
	{
		if ((_recipient != "") && (_message != ""))
			return true;
		else
			return false;
	}

	SMSMessage::SMSMessage() :SMSMessage("0123456789", "test")
	{
	}

	SMSMessage::SMSMessage(String ^rec, String ^msg)
	{
		_phoneNumber = rec;
		_message = msg;
	}

	bool SMSMessage::Send()
	{
		if ((_phoneNumber != "") && (_message != ""))
			return true;
		else
			return false;
	}

	ChatMessage::ChatMessage() :ChatMessage("defaultUser", "test")
	{
	}

	ChatMessage::ChatMessage(String ^ rec, String ^ msg)
	{
		_recipient = rec;
		_message = msg;
	}

	bool ChatMessage::Send()
	{
		if ((_recipient != "") && (_message != ""))
			return true;
		else
			return false;
	}
}
