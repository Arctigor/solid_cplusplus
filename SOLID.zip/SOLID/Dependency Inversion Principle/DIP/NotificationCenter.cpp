#include "NotificationCenter.h"

NotificationCenter::NotificationCenter()
{
}

void NotificationCenter::SendNotifications()
{
	for each (IGenericMessage^ msg in _messages)
	{
		msg->Send();
	}
}

NotificationCenterNonInherit::NotificationCenterNonInherit()
{
}

void NotificationCenterNonInherit::SendNotifications()
{
	_email->SendEmail();
	_sms->SendSMS();
	_chat->SendChat();
}