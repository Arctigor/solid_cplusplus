﻿#include "stdafx.h"

using namespace System;
using namespace System::Text;
using namespace System::Collections::Generic;
using namespace Microsoft::VisualStudio::TestTools::UnitTesting;

namespace TestProject
{
	[TestClass]
	public ref class UnitTest
	{
	private:
		TestContext^ testContextInstance;
		static Cart^ c;
		static OrderItem^ item;
		static PaymentDetails^ paymentDetails;
	public:
		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		property Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ TestContext
		{
			Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ get()
			{
				return testContextInstance;
			}
			System::Void set(Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ value)
			{
				testContextInstance = value;
			}
		};

#pragma region Additional test attributes
		//
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		[ClassInitialize()]
		static void MyClassInitialize(Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ testContextInstance)
		{
			c = gcnew Cart();
			item = gcnew OrderItem(10, "ASDERTY");
			List<OrderItem^>^ items = gcnew List<OrderItem^>();
			items->Add(item);
			Assert::AreNotEqual(nullptr, items);
			c->SetItems(items);
			c->SetCustomerEmail("a@a.com");
			c->SetTotalAmount(100.20);
			paymentDetails = gcnew PaymentDetails();
			paymentDetails->SetCardHolderName("aaaa bbb");
			paymentDetails->SetCardNumber("012345678910");
			paymentDetails->SetExpireMonth("May");
			paymentDetails->SetExpireYear("2020");
		};

		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//static void MyClassCleanup() {};
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//void MyTestInitialize() {};
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//void MyTestCleanup() {};
		//
#pragma endregion 

		[TestMethod]
		void CartTest()
		{
			Assert::AreEqual(100.20, c->GetTotalAmount());
		};

		[TestMethod]
		inline void UnitTest::PaymentTest_Mail_Card()
		{
			try {
				paymentDetails->SetPaymentMethod(PaymentMethod::CreditCard);//Card
				//Order^ order = gcnew Order();
				//order->Checkout(c, paymentDetails, true);
				OnlineOrder^ order = gcnew OnlineOrder(c, paymentDetails);
				order->Checkout();
			}
			catch (Exception^ ex)
			{
				Assert::Inconclusive("Exception occured: " + ex->Message);
			}
		}

		[TestMethod]
		inline void UnitTest::PaymentTest_Card()
		{
			try {
				PaymentDetails^ paymentDetails = gcnew PaymentDetails();
				//Order^ order = gcnew Order();
				//order->Checkout(c, paymentDetails, false);
				PoSCreditOrder^ order = gcnew PoSCreditOrder(c, paymentDetails);
				order->Checkout();
			}
			catch (Exception^ ex)
			{
				Assert::Inconclusive("Exception occured: " + ex->Message);
			}
		}

		[TestMethod]
		inline void UnitTest::PaymentTest_Cash()
		{
			try {
				paymentDetails->SetPaymentMethod(PaymentMethod::Cash);//Card
				//Order^ order = gcnew Order();
				//order->Checkout(c, paymentDetails, true);
				PoSCashOrder^ order = gcnew PoSCashOrder(c);
				order->Checkout();
			}
			catch (Exception^ ex)
			{
				Assert::Inconclusive("Exception occured: " + ex->Message);
			}
		}
	};
}
