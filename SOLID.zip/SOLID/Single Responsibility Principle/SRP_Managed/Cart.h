#pragma once
#include <string>
using namespace System;
using namespace System::Collections::Generic;


public ref class OrderItem
{
public:
	void SetQuantity( int value ) { _quantity = value; };
	int GetQuantity() { return _quantity; };
	void SetSKU( String^ value ) { _sku = value; };
	String^ GetSKU() { return _sku; };
	OrderItem( int, String^ );
	String^ ToString() override;
private:
	int _quantity;
	String^ _sku;
};

public ref class Cart
{
public:
	void SetTotalAmount( float value ) { _totalAmount = value; };
	float GetTotalAmount();
	void SetItems( List<OrderItem^>^ value ) { _items = value; };
	List<OrderItem^>^ GetItems() { return _items; };
	void SetCustomerEmail( String^ value ) { _customerEmail = value; };
	String^ GetCustomerEmail() { return _customerEmail; };
	Cart( String^ );
	Cart();

private:
	float _totalAmount;
	String^ _customerEmail;
	List<OrderItem^>^ _items;
};
