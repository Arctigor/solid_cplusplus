#include "Order.h"

using namespace System;
using namespace System::Net::Mail;

Order::Order(Cart ^ cart)
{
	_cart = cart;
}

void Order::Checkout()
{
	//throw gcnew OrderException("base class method called",nullptr);
}

OnlineOrder::OnlineOrder(Cart^ cart, PaymentDetails^ details):Order(cart)
{
	_notificationService = gcnew NotificationService();
	_paymentProcessor = gcnew PaymentProcessor();
	_reservationService = gcnew ReservationService();
	_paymentDetails = details;
}

void OnlineOrder::Checkout()
{
	_paymentProcessor->ProcessCreditCard(_paymentDetails, GetCart()->GetTotalAmount());
	_reservationService->ReserveInventory(GetCart()->GetItems());
	_notificationService->NotifyCustomerOrderCreated(GetCart());
	Order::Checkout();
}

PoSCreditOrder::PoSCreditOrder(Cart ^ cart, PaymentDetails ^ details):Order(cart)
{
	_paymentProcessor = gcnew PaymentProcessor();
	_paymentDetails = details;
}

void PoSCreditOrder::Checkout()
{
	_paymentProcessor->ProcessCreditCard(_paymentDetails, GetCart()->GetTotalAmount());
	Order::Checkout();
}

PoSCashOrder::PoSCashOrder(Cart^ cart):Order(cart)
{
	
}
