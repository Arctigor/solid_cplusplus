#pragma once
#include "Cart.h"
#include "PaymentDetails.h"
#include "InventorySystem.h"
#include "PaymentGateway.h"
#include "NotificationService.h"
#include "PaymentProcessor.h"
#include "ReservationService.h"

public ref  class Order abstract
{
public:
	Order(Cart^);
	void SetCart(Cart^ value) { _cart = value; };
	Cart^ GetCart() { return _cart; };
	virtual void Checkout();
private:
	Cart^ _cart;
};

public ref class OnlineOrder :Order
{
public:
	OnlineOrder(Cart^, PaymentDetails^);
	void Checkout() override;
private:
	INotificationService^ _notificationService;
	PaymentDetails^ _paymentDetails;
	IPaymentProcessor^ _paymentProcessor;
	IReservationService^ _reservationService;
};

public ref class PoSCreditOrder :Order
{
public:
	PoSCreditOrder(Cart^, PaymentDetails^);
	void Checkout() override;
private:
	PaymentDetails^ _paymentDetails;
	IPaymentProcessor^ _paymentProcessor;
};

public ref class PoSCashOrder :Order
{
public:
	PoSCashOrder(Cart^);
private:
};

public ref class OrderException :Exception
{
public:
	OrderException(String^ message, Exception^ innerException) : Exception(message, innerException) {};
};