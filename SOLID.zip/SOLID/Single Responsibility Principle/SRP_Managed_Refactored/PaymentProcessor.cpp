#include "PaymentProcessor.h"
#include "PaymentGateway.h"
#include "Order.h"

PaymentProcessor::PaymentProcessor()
{
}

void PaymentProcessor::ProcessCreditCard(PaymentDetails^ paymentDetails, double amount)
{
	PaymentGateway^ paymentGateway = gcnew PaymentGateway();
	{
		try
		{
			paymentGateway->SetCredentials("account credentials");
			paymentGateway->SetCardNumber(paymentDetails->GetCardNumber());
			paymentGateway->SetExpireMonth(paymentDetails->GetExpireMonth());
			paymentGateway->SetExpireYear(paymentDetails->GetExpireYear());
			paymentGateway->SetCardHolderName(paymentDetails->GetCardHolderName());
			paymentGateway->SetChargeAmount(amount);
			paymentGateway->Charge();
		}
		catch (AvsMismatchException^ ex)
		{
			throw gcnew OrderException("The card gateway rejected the card based on the address provided.", ex);
		}
		catch (Exception^ ex)
		{
			throw gcnew OrderException("There was a problem with your card.", ex);
		}
	}
}
