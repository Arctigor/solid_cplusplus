#pragma once
#include"Cart.h"
using namespace System;
using namespace System::Collections::Generic;

interface class IReservationService
{
	void ReserveInventory(List<OrderItem^>^);
};

ref class ReservationService:IReservationService
{
public:
	ReservationService();

	// Inherited via IReservationService
	virtual void ReserveInventory(List<OrderItem^>^);
};

