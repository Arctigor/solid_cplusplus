#include "InventorySystem.h"

InventorySystem::InventorySystem()
{
}

void InventorySystem::Reserve(String ^, int)
{
	throw gcnew InsufficientInventoryException();
}
