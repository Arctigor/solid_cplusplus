#pragma once
#include "Cart.h"
#include "PaymentDetails.h"
#include "InventorySystem.h"
#include "PaymentGateway.h"

public ref class Order
{
public:
	Order();
	void Checkout(Cart^, PaymentDetails^, bool);
	void NotifyCustomer(Cart^);
	void ReserveInventory(Cart^);
	void ChargeCard(PaymentDetails^, Cart^);
};

public ref class OrderException :Exception
{
public:
	OrderException(String^ message, Exception^ innerException) : Exception(message, innerException) {};
};

