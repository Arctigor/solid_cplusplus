#pragma once
using namespace System;

public ref class OrderItem
{
public:
	void SetQuantity(int value) { _quantity = value; };
	int GetQuantity() { return _quantity; };
	void SetSKU(String^ value) { _sku = value; };
	String^ GetSKU() { return _sku; };
	OrderItem(int, String^);
	String^ ToString() override;
private:
	int _quantity;
	String^ _sku;
};

