#pragma once

using namespace System;

public enum class PaymentMethod
{
	Cash,
	CreditCard
};

public ref class PaymentDetails
{

public:
	PaymentDetails();
	void SetPaymentMethod(PaymentMethod^ method) { _paymentMethod = method; };
	void SetCardNumber(String^ value) { _creditCardNumber = value; };
	void SetExpireMonth(String^ value) { _expireMonth = value; };
	void SetExpireYear(String^ value) { _expireYear = value; };
	void SetCardHolderName(String^ value) { _cardholderName = value; };
	PaymentMethod^ GetPaymentMethod() { return _paymentMethod; };
	String^ GetCardNumber() { return _creditCardNumber; };
	String^ GetExpireMonth() { return _expireMonth; };
	String^ GetExpireYear() { return _expireYear; };
	String^ GetCardHolderName() { return _cardholderName; };

private:
	PaymentMethod^ _paymentMethod;
	String^ _creditCardNumber;
	String^ _expireMonth;
	String^ _expireYear;
	String^ _cardholderName;
};

