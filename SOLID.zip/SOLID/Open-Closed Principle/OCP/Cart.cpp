#include "Cart.h"

Cart::Cart()
{
	_totalAmount = 0;
	_customerEmail = "";
	_items = gcnew List<OrderItem^>();
}

Cart::Cart( String^ email )
{
	_totalAmount = 0;
	_customerEmail = email;
	_items = gcnew List<OrderItem^>();
}


void Cart::Add( OrderItem ^ item )
{
	_items->Add( item );
}

float Cart::GetTotalAmount()
{
	_totalAmount = 0;
	
	for each( OrderItem^ orderItem in _items )
	{
		if ( orderItem->GetSKU()->StartsWith("EACH") )
		{
			_totalAmount += orderItem->GetQuantity() * 5;
		}
		else if ( orderItem->GetSKU()->StartsWith("WEIGHT") )
		{
			// quantity is in grams, price is per kg
			_totalAmount += orderItem->GetQuantity() * 4 / 1000;
		}
		else if ( orderItem->GetSKU()->StartsWith("SPECIAL") )
		{
			// $0.40 each; 3 for a $1.00
			_totalAmount += orderItem->GetQuantity() * 0.4;
			int setsOfThree = orderItem->GetQuantity() / 3;
			_totalAmount -= setsOfThree*0.2;
		}
		// more rules are coming!
	}
	return _totalAmount;
}


OrderItem::OrderItem( int quantity, String^ sku )
{
	_sku = sku;
	_quantity = quantity;
}


String ^ OrderItem::ToString()
{
	return "asd";// TODO: insert return statement here
}
