﻿#include "stdafx.h"

using namespace System;
using namespace System::Text;
using namespace System::Collections::Generic;
using namespace Microsoft::VisualStudio::TestTools::UnitTesting;

namespace OCP_Test
{
	[TestClass]
	public ref class UnitTest
	{
	private:
		TestContext^ testContextInstance;
		static Cart^ _cart;
	public:
		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		property Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ TestContext
		{
			Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ get()
			{
				return testContextInstance;
			}
			System::Void set(Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ value)
			{
				testContextInstance = value;
			}
		};

#pragma region Additional test attributes
		//
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		[ClassInitialize()]
		static void MyClassInitialize(Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ testContext)
		{
			_cart = gcnew Cart();
		}
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//static void MyClassCleanup() {};
		//
		//Use TestInitialize to run code before running each test
		[TestInitialize()]
		void MyTestInitialize() {
			_cart = gcnew Cart();
		};
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//void MyTestCleanup() {};
		//
#pragma endregion 

		[TestMethod]
		void ZeroWhenEmpty()
		{
			Assert::AreEqual((float)0.0, _cart->GetTotalAmount());
		}

		[TestMethod]
		void FiveWithOneEachItem()
		{
			_cart->Add(gcnew OrderItem(1, "EACH_WIDGET"));
			Assert::AreEqual((float)5.0, _cart->GetTotalAmount());
		}

		[TestMethod]
		void TwoWithHalfKiloWeightItem()
		{
			_cart->Add(gcnew OrderItem(500,"WEIGHT_PEANUTS"));
			Assert::AreEqual((float)2.0, _cart->GetTotalAmount());
		}

		[TestMethod]
		void EightyCentsWithTwoSpecialItem()
		{
			_cart->Add(gcnew OrderItem(2,"SPECIAL_CANDYBAR"));
			Assert::AreEqual((float)0.8, _cart->GetTotalAmount());
		}
		[TestMethod]
		void TwoDollarsWithSixSpecialItem()
		{
			_cart->Add(gcnew OrderItem(6,"SPECIAL_CANDYBAR"));
			Assert::AreEqual((float)2.0,_cart->GetTotalAmount());
		}
		[TestMethod]
		void FourDollarsWithFourBuy4Get1FreeItems()
		{
			_cart->Add(gcnew OrderItem(4,"B4GO_APPLE"));
			Assert::AreEqual((float)4.0, _cart->GetTotalAmount());
		}
		[TestMethod]
		void FourDollarsWithFiveBuy4Get1FreeItems()
		{
			_cart->Add(gcnew OrderItem(5,"B4GO_APPLE"));
			Assert::AreEqual((float)4.0, _cart->GetTotalAmount());
		}
	};
}
