#include "OrderItem.h"

OrderItem::OrderItem(int quantity, String^ sku)
{
	_sku = sku;
	_quantity = quantity;
}


String ^ OrderItem::ToString()
{
	return _sku;// TODO: insert return statement here
}