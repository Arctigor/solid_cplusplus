#pragma once
#include "PriceRule.h"

using namespace System::Collections::Generic;

interface class IPricingCalculator
{
public:
	float CalculatePrice(OrderItem^ item);
};

ref class PricingCalculator:IPricingCalculator
{
public:
	PricingCalculator();
	// Inherited via IPricingCalculator
	virtual float CalculatePrice(OrderItem ^ item);
private:
	List<IPriceRule^>^ _pricingRules;
};

ref class PriceException :System::Exception
{
public:
	PriceException(OrderItem^ item) :Exception("No price rule found for: "+ item->ToString(), nullptr) {};;
};

