#pragma once

#include "PricingCalculator.h"
#include "OrderItem.h"

using namespace System;
using namespace System::Collections::Generic;

public ref class Cart
{
public:
	void SetTotalAmount(float value) { _totalAmount = value; };
	float GetTotalAmount();
	void SetItems(List<OrderItem^>^ value) { _items = value; };
	List<OrderItem^>^ GetItems() { return _items; };
	void SetCustomerEmail(String^ value) { _customerEmail = value; };
	String^ GetCustomerEmail() { return _customerEmail; };
	void Add(OrderItem ^ item);
	Cart();
	Cart(String^);
	Cart(IPricingCalculator^ pricingCalculator);

private:
	float _totalAmount;
	String^ _customerEmail;
	List<OrderItem^>^ _items;
	IPricingCalculator^ _pricingCalculator;
};