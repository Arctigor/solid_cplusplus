#pragma once
#include "OrderItem.h"

interface class IPriceRule
{
public:
	bool isMatch(OrderItem^);
	float CalculatePrice(OrderItem^);
};

public ref class PerGramPriceRule : IPriceRule
{
public:
	// Inherited via IPriceRule
	virtual bool isMatch(OrderItem ^);
	virtual float CalculatePrice(OrderItem ^);
};

public ref class EachPriceRule : IPriceRule
{
public:
	// Inherited via IPriceRule
	virtual bool isMatch(OrderItem ^);
	virtual float CalculatePrice(OrderItem ^);
};

public ref class SpecialPriceRule : IPriceRule
{
public:
	// Inherited via IPriceRule
	virtual bool isMatch(OrderItem ^);
	virtual float CalculatePrice(OrderItem ^);
};

public ref class Buy4GetOneFree : IPriceRule
{
public:
	// Inherited via IPriceRule
	virtual bool isMatch(OrderItem ^);
	virtual float CalculatePrice(OrderItem ^);
};