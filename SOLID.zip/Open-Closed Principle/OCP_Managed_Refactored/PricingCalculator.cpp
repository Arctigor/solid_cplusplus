#include "PricingCalculator.h"

PricingCalculator::PricingCalculator()
{
	_pricingRules = gcnew List<IPriceRule^>();
	_pricingRules->Add(gcnew EachPriceRule());
	_pricingRules->Add(gcnew PerGramPriceRule());
	_pricingRules->Add(gcnew SpecialPriceRule());
	_pricingRules->Add(gcnew Buy4GetOneFree());
}

float PricingCalculator::CalculatePrice(OrderItem ^ item)
{
	for each(IPriceRule^ rule in _pricingRules)
	{
		if (rule->isMatch(item))
		{
			return rule->CalculatePrice(item);
		}
	}
	throw gcnew PriceException(item);
	return 0.0;
}
