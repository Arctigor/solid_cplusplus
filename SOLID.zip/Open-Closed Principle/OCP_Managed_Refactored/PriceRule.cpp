#include "PriceRule.h"

bool PerGramPriceRule::isMatch(OrderItem ^ item)
{
	return item->GetSKU()->StartsWith("WEIGHT");
}

float PerGramPriceRule::CalculatePrice(OrderItem ^ item)
{
	return item->GetQuantity() * (float)4.0 / (float)1000;
}

bool EachPriceRule::isMatch(OrderItem ^ item)
{
	return item->GetSKU()->StartsWith("EACH");
}

float EachPriceRule::CalculatePrice(OrderItem ^ item)
{
	return item->GetQuantity() * (float)5.0;
}

bool SpecialPriceRule::isMatch(OrderItem ^ item)
{
	return item->GetSKU()->StartsWith("SPECIAL");
}

float SpecialPriceRule::CalculatePrice(OrderItem ^ item)
{
	float total = 0;
	// $0.40 each; 3 for a $1.00
	total += item->GetQuantity()*(float).4;
	int setsOfThree = item->GetQuantity() / 3;
	total -= setsOfThree*(float).2;
	return total;
}

bool Buy4GetOneFree::isMatch(OrderItem ^ item)
{
	return item->GetSKU()->StartsWith("B4GO");
}

float Buy4GetOneFree::CalculatePrice(OrderItem ^ item)
{
	float total = 0;
	// $0.40 each; 3 for a $1.00
	total += item->GetQuantity()*(float)1;
	int setsOfThree = item->GetQuantity() / 5;
	total -= setsOfThree*(float)1;
	return total;
}