#include "Cart.h"

Cart::Cart():Cart(gcnew PricingCalculator())
{
	_totalAmount = 0;
	_customerEmail = "";
	_items = gcnew List<OrderItem^>();
}

Cart::Cart(String^ email):Cart(gcnew PricingCalculator())
{
	_totalAmount = 0;
	_customerEmail=email;
	_items = gcnew List<OrderItem^>();
}

Cart::Cart( IPricingCalculator^ pricingCalculator)
{
	_pricingCalculator = pricingCalculator;
}

void Cart::Add(OrderItem ^ item)
{
	_items->Add(item);
}

float Cart::GetTotalAmount()
{
	_totalAmount = 0;
	for each(OrderItem^ orderItem in _items)
	{
		_totalAmount += _pricingCalculator->CalculatePrice(orderItem);
	}
	return _totalAmount;
}
