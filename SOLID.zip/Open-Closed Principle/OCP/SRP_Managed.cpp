// This is the main DLL file.

#include "SRP_Managed.h"

