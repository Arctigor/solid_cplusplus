#pragma once
using namespace System;

ref class InventorySystem
{
public:
	InventorySystem();
	void Reserve( String^, int );
};

ref class InsufficientInventoryException : Exception
{
public:
	InsufficientInventoryException() : Exception( "Insufficient inventory", nullptr ) {};
};
