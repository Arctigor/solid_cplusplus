#include "PaymentGateway.h"

PaymentGateway::PaymentGateway()
{
}

void PaymentGateway::Charge()
{
	throw gcnew AvsMismatchException();
}
