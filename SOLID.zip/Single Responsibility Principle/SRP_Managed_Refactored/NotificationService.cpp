#include "NotificationService.h"

using namespace System::Net::Mail;

NotificationService::NotificationService()
{
}

void NotificationService::NotifyCustomerOrderCreated(Cart ^ cart)
{
	String^ fromEmail = "office@example.com";
	if (cart->GetCustomerEmail() != "")
	{
		MailMessage^ message;
		message = gcnew MailMessage(fromEmail, cart->GetCustomerEmail());
		SmtpClient^ client = gcnew SmtpClient("localhost");
		{
			message->Subject = "Your order placed on " + DateTime::Now.ToString();
			message->Body = "Your order details: \n " + cart->ToString();
			try
			{
				client->Send(message);
			}
			catch (Exception^)
			{
				//Logger.Error("Problem sending notification email", ex);
			}
		}
	}
}
