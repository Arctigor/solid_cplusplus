#include "ReservationService.h"
#include "InventorySystem.h"
#include "Order.h"

ReservationService::ReservationService()
{
}

void ReservationService::ReserveInventory(List<OrderItem^>^ items)
{
	for each(OrderItem^ item in items)
	{
		try
		{
			InventorySystem^ inventorySystem = gcnew InventorySystem();
			inventorySystem->Reserve(item->GetSKU(), item->GetQuantity());
		}
		catch (InsufficientInventoryException^ ex)
		{
			throw gcnew OrderException("Insufficient inventory for item " + item->GetSKU(), ex);
		}
		catch (Exception^ ex)
		{
			throw gcnew OrderException("Problem reserving inventory", ex);
		}
	}
}
