#pragma once
#include "PaymentDetails.h"

interface class IPaymentProcessor
{
	void ProcessCreditCard(PaymentDetails^ paymentDetails, double amount);
};

ref class PaymentProcessor:IPaymentProcessor
{
public:
	PaymentProcessor();

	// Inherited via IPaymentProcessor
	virtual void ProcessCreditCard(PaymentDetails^ paymentDetails, double amount);
};

