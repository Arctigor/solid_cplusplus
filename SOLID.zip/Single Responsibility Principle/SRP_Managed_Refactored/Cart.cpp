#include "Cart.h"


Cart::Cart()
{
	_totalAmount = 0;
	_customerEmail = "";
	_items = gcnew List<OrderItem^>();
}

Cart::Cart(String^ email)
{
	_totalAmount = 0;
	_customerEmail=email;
	_items = gcnew List<OrderItem^>();
}


OrderItem::OrderItem(int quantity, String^ sku)
{
	_sku = sku;
	_quantity = quantity;
}


String ^ OrderItem::ToString()
{
	return "asd";// TODO: insert return statement here
}
