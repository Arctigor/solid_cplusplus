#pragma once
#include"Cart.h"

interface class INotificationService
{
	void NotifyCustomerOrderCreated(Cart^ cart);
};

ref class NotificationService:INotificationService
{
public:
	NotificationService();
	// Inherited via INotificationService
	virtual void NotifyCustomerOrderCreated(Cart ^ cart);
};

