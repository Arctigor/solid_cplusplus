#include "Order.h"

using namespace System;
using namespace System::Net::Mail;

Order::Order()
{
}

void Order::Checkout( Cart^ cart, PaymentDetails^ paymentDetails, bool notifyCustomer )
{
	if ( paymentDetails->GetPaymentMethod() == PaymentMethod::CreditCard )
	{
		ChargeCard( paymentDetails, cart );
	}

	ReserveInventory( cart );

	if ( notifyCustomer )
	{
		NotifyCustomer( cart );
	}
}


void Order::NotifyCustomer( Cart^ cart )
{
	String^ fromEmail = "office@example.com";
	if ( cart->GetCustomerEmail() != "" )
	{
		MailMessage^ message;
		message = gcnew MailMessage( fromEmail, cart->GetCustomerEmail() );
		SmtpClient^ client = gcnew SmtpClient( "localhost" );
			{
				message->Subject = "Your order placed on " + DateTime::Now.ToString();
				message->Body = "Your order details: \n " + cart->ToString();
				try
				{
					client->Send( message );
				}
				catch ( Exception^ )
				{
					//Logger.Error("Problem sending notification email", ex);
				}
			}
		}
	
}

void Order::ReserveInventory( Cart^ cart )
{
	for each( OrderItem^ item in cart->GetItems() )
	{
		try
		{
			InventorySystem^ inventorySystem = gcnew InventorySystem();
			inventorySystem->Reserve( item->GetSKU(), item->GetQuantity() );
		}
		catch ( InsufficientInventoryException^ ex )
		{
			throw gcnew OrderException( "Insufficient inventory for item " + item->GetSKU(), ex );
		}
		catch ( Exception^ ex )
		{
			throw gcnew OrderException( "Problem reserving inventory", ex );
		}
	}
}

void Order::ChargeCard( PaymentDetails^ paymentDetails, Cart^ cart )
{
	PaymentGateway^ paymentGateway = gcnew PaymentGateway();
	{
		try
		{
			paymentGateway->SetCredentials( "account credentials");
			paymentGateway->SetCardNumber( paymentDetails->GetCardNumber() );
			paymentGateway->SetExpireMonth( paymentDetails->GetExpireMonth() );
			paymentGateway->SetExpireYear( paymentDetails->GetExpireYear() );
			paymentGateway->SetCardHolderName( paymentDetails->GetCardHolderName() );
			paymentGateway->SetChargeAmount( cart->GetTotalAmount() );
			paymentGateway->Charge();
		}
		catch ( AvsMismatchException^ ex )
		{
			throw gcnew OrderException( "The card gateway rejected the card based on the address provided.", ex );
		}
		catch ( Exception^ ex )
		{
			throw gcnew OrderException( "There was a problem with your card.", ex );
		}
	}
}
