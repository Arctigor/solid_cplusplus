#pragma once
using namespace System;

public ref class PaymentGateway
{
public:
	PaymentGateway();
	void SetCardNumber( String^ value ) { _creditCardNumber = value; };
	void SetCredentials( String^ value ) { _credentials = value; };
	void SetExpireMonth( String^ value ) { _expireMonth = value; };
	void SetExpireYear( String^ value ) { _expireYear = value; };
	void SetCardHolderName( String^ value ) { _nameOnCard = value; };
	void SetChargeAmount( float value ) { _amount = value; };
	String^ GetCardNumber() { return _creditCardNumber; };
	String^ GetCredentials() { return _credentials; };
	String^ GetExpireMonth() { return _expireMonth; };
	String^ GetExpireYear() { return _expireYear; };
	String^ GetCardHolderName() { return _nameOnCard; };
	float GetChargeAmount() { return _amount; };
	void Charge();

private:
	String^ _creditCardNumber;
	String^ _credentials;
	String^ _expireMonth;
	String^ _expireYear;
	String^ _nameOnCard;
	float _amount;
};

public ref class AvsMismatchException : Exception
{
public:
	AvsMismatchException() :Exception( "Avs mismatch!", nullptr ) {};
};
