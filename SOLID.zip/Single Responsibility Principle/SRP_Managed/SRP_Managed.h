// SRP_Managed.h

#pragma once

using namespace System;

namespace SRP_Managed {

	public ref class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
