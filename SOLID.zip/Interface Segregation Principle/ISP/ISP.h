// ISP.h

#pragma once

using namespace System;

namespace ISP {

	interface class IVehicle
	{
	public:
		 String^ Start();
		 String^ Stop();
		 String^ Steer();
		 String^ Accelerate();
		 String^ Brake();
		 String^ ChargeMainBattery();
		 String^ FillFuelTank();
		 String^ ChangeGear(int);//-1/1
		static int _currentGear;
	};

	public ref class InternalCombustionCar:IVehicle
	{
	public:
		// Inherited via IVehicle
		virtual String^ Start();
		virtual String^ Stop();
		virtual String^ Steer();
		virtual String^ Accelerate();
		virtual String^ Brake();
		virtual String^ ChargeMainBattery();
		virtual String^ FillFuelTank();
		virtual String^ ChangeGear(int);
		static int _currentGear;
	};

	public ref class AutomaticInternalCombustionCar:IVehicle
	{
	public:
		// Inherited via IVehicle
		virtual String^ Start();
		virtual String^ Stop();
		virtual String^ Steer();
		virtual String^ Accelerate();
		virtual String^ Brake();
		virtual String^ ChargeMainBattery();
		virtual String^ FillFuelTank();
		virtual String^ ChangeGear(int);
	};

	public ref class ElectricCar:IVehicle
	{
	public:
		// Inherited via IVehicle
		virtual String^ Start();
		virtual String^ Stop();
		virtual String^ Steer();
		virtual String^ Accelerate();
		virtual String^ Brake();
		virtual String^ ChargeMainBattery();
		virtual String^ FillFuelTank();
		virtual String^ ChangeGear(int);
	};
}
