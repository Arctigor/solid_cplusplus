
#include "ISP_Refactored.h"

String^ ISP_Refactored::InternalCombustionCar::Start()
{
	_currentGear = 0;
	return "Car started";
}

String^ ISP_Refactored::InternalCombustionCar::Stop()
{
	_currentGear = 0;
	return "Car stopped";
}

String^ ISP_Refactored::InternalCombustionCar::Steer()
{
	return "Car is steering";
}

String^ ISP_Refactored::InternalCombustionCar::Accelerate()
{
	return "Car accelerates";
}

String^ ISP_Refactored::InternalCombustionCar::Brake()
{
	return "Brakes applied";
}

String^ ISP_Refactored::InternalCombustionCar::FillFuelTank()
{
	return "The fuel tank is full";
}

String^ ISP_Refactored::InternalCombustionCar::ChangeGear(int gear)
{
	_currentGear = gear;
	return "Gear change complete";
}

String^ ISP_Refactored::ElectricCar::Start()
{
	return "Car started";
}

String^ ISP_Refactored::ElectricCar::Stop()
{
	return "Car stopped";
}

String^ ISP_Refactored::ElectricCar::Steer()
{
	return "Car is steering";
}

String^ ISP_Refactored::ElectricCar::Accelerate()
{
	return "Car accelerates";
}

String^ ISP_Refactored::ElectricCar::Brake()
{
	return "Brakes applied";
}

String^ ISP_Refactored::ElectricCar::ChargeMainBattery()
{
	return "Batteries charged";
}

String ^ ISP_Refactored::AutomaticInternalCombustionCar::Start()
{
	return "Car started";
}

String ^ ISP_Refactored::AutomaticInternalCombustionCar::Stop()
{
	return "Car stopped";
}

String ^ ISP_Refactored::AutomaticInternalCombustionCar::Steer()
{
	return "Car is steering";
}

String ^ ISP_Refactored::AutomaticInternalCombustionCar::Accelerate()
{
	return "Car accelerates";
}

String ^ ISP_Refactored::AutomaticInternalCombustionCar::Brake()
{
	return "Brakes applied";
}

String ^ ISP_Refactored::AutomaticInternalCombustionCar::FillFuelTank()
{
	return "The fuel tank is full";
}