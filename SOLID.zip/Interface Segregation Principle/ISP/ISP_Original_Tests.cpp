#include "ISP.h"
using namespace ISP;
using namespace System;
using namespace System::Text;
using namespace System::Collections::Generic;
using namespace Microsoft::VisualStudio::TestTools::UnitTesting;
[TestClass]
public ref class TestClass
{

public:
	static String^ start = "Car started";
	static String^ stop = "Car stopped";
	static String^ accel = "Car accelerates";
	static String^ brake = "Brakes applied";
	static String^ steer = "Car is steering";
	static String^ fill = "The fuel tank is full";
	static String^ charge = "Batteries charged";
	static String^ gearchange = "Gear change complete";

	[TestMethod]
	void TestElectricCar()
	{
		IVehicle^ electricCar = gcnew ElectricCar();
		Assert::AreEqual(start, electricCar->Start());
		Assert::AreEqual(accel, electricCar->Accelerate());
		Assert::AreEqual(steer, electricCar->Steer());
		Assert::AreEqual(brake, electricCar->Brake());
		Assert::AreEqual(stop, electricCar->Stop());
		Assert::AreEqual(charge, electricCar->ChargeMainBattery());
	}
	[TestMethod]
	void TestICCar()
	{
		IVehicle^ icCar = gcnew InternalCombustionCar();
		Assert::AreEqual(start, icCar->Start());
		Assert::AreEqual(accel, icCar->Accelerate());
		Assert::AreEqual(steer, icCar->Steer());
		Assert::AreEqual(brake, icCar->Brake());
		Assert::AreEqual(gearchange, icCar->ChangeGear(1));
		Assert::AreEqual(stop, icCar->Stop());
		Assert::AreEqual(fill, icCar->FillFuelTank());
	}
	[TestMethod]
	void TestElectricCarAsIC()
	{
		IVehicle^ icCar = gcnew ElectricCar();
		Assert::AreEqual(start, icCar->Start());
		Assert::AreEqual(accel, icCar->Accelerate());
		Assert::AreEqual(steer, icCar->Steer());
		Assert::AreEqual(brake, icCar->Brake());
		Assert::AreEqual(gearchange, icCar->ChangeGear(1));
		Assert::AreEqual(stop, icCar->Stop());
		Assert::AreEqual(fill, icCar->FillFuelTank());
	}
	[TestMethod]
	void TestICCarAsElectric()
	{
		IVehicle^ electricCar = gcnew InternalCombustionCar();
		Assert::AreEqual(start, electricCar->Start());
		Assert::AreEqual(accel, electricCar->Accelerate());
		Assert::AreEqual(steer, electricCar->Steer());
		Assert::AreEqual(brake, electricCar->Brake());
		Assert::AreEqual(stop, electricCar->Stop());
		Assert::AreEqual(charge, electricCar->ChargeMainBattery());
	}
};