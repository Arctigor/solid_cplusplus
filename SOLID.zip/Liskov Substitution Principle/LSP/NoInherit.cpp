#include "NoInherit.h"

using namespace System;
using namespace System::Text;
using namespace System::Collections::Generic;
using namespace Microsoft::VisualStudio::TestTools::UnitTesting;

[TestClass]
public ref class NoInherit
{

public:
	[TestMethod]
	void SixFor2X3Rectangle()
	{
		RectangleShapeNoIn^ myRectangle = gcnew RectangleShapeNoIn(2,3);
		Assert::AreEqual(6, myRectangle->Area());
	}

	[TestMethod]
	void NineFor3X3Square()
	{
		SquareShapeNoIn^ mySquare = gcnew SquareShapeNoIn(3);
		Assert::AreEqual(9, mySquare->Area());
	}

	[TestMethod]
	void TwentyFor4X5ShapeFromRectangleAnd9For3X3Square()
	{
		List<Shape^>^ shapes = gcnew List<Shape^>();
		shapes->Add(gcnew RectangleShapeNoIn(4, 5));
		shapes->Add(gcnew SquareShapeNoIn(3));
		List<int>^ areas = gcnew List<int>();
		for each(Shape^ shape in shapes)
		{
			if (shape->GetType() == RectangleShapeNoIn::typeid)
			{
				areas->Add(((RectangleShapeNoIn^)shape)->Area());
			}
			if (shape->GetType() == SquareShapeNoIn::typeid)
			{
				areas->Add(((SquareShapeNoIn^)shape)->Area());
			}
		}
		Assert::AreEqual(20, areas[0]);
		Assert::AreEqual(9, areas[1]);
	}
};

RectangleShapeNoIn::RectangleShapeNoIn(int width, int height)
{
	_width = width;
	_height = height;
}
