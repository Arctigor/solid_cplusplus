// LSP.h

#pragma once

using namespace System;

namespace LSP {

	public ref class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
