#pragma once
public ref class Shape
{
public:
	Shape() {};
};


public ref class RectangleShapeNoIn : Shape
{
public:
	RectangleShapeNoIn() {};
	RectangleShapeNoIn(int, int);
	int GetWidth() { return _width; };
	int GetHeight() { return _height; };
	void SetWidth(int value) { _width = value; };
	void SetHeight(int value) { _height = value; };
	int Area() { return _width*_height; }
	~RectangleShapeNoIn() {};
private:
	int _width = 0;
	int _height = 0;
};

public ref class SquareShapeNoIn : Shape
{
public:
	SquareShapeNoIn() {};
	SquareShapeNoIn(int side) { _side = side; };
	int GetSide() { return _side; };
	void SetSide(int value) { _side = value; };
	int Area() { return _side*_side; }
	~SquareShapeNoIn() {};
private:
	int _side = 0;
};

